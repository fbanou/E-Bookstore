import React from 'react'
import './Footer.css'
import logo from '../Assets/logo_icon.png'
import linkedin_icon from '../Assets/linkedin.png'
import facebook from '../Assets/facebook-app-symbol.png'
import tik_tok from '../Assets/tik-tok.png'
import instagram from '../Assets/instagram.png'

const Footer = () => {
    return (
        <div className='footer'>
            <div className="footer-logo">
                <img src={logo} alt="" />
                <div style={{ 
                    display: 'flex', 
                    flexDirection: 'column', 
                    alignItems: 'center', 
                    justifyContent: 'center', 
                    height: '100vh' 
                }}>
                <div style={{ fontSize: '24px', fontWeight: 'bold' }}>BOOKSTORE</div>
                <div style={{ fontSize: '16px', marginTop: '10px' }}>Books that inspire you</div>
                </div>
            </div>
            <ul className="footer-links">
                <li>About us</li>
                <li>Products</li>
                <li>Contact</li>
            </ul>
            <div className="footer-social-icon">
                <div className="footer-icons-container">
                    <img src={linkedin_icon} alt="" />
                </div>
                <div className="footer-icons-container">
                    <img src={facebook} alt="" />
                </div>
                <div className="footer-icons-container">
                    <img src={tik_tok} alt="" />
                </div>
                <div className="footer-icons-container">
                    <img src={instagram} alt="" />
                </div>

            </div>
        </div>
    )
}

export default Footer