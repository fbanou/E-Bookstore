import b1_img from "./book_1.jpg";
import b2_img from "./book_2.jpg";

let data_product = [
    {
        id:1,
        name: "Από την ανασφάλεια στην αυτοπεποίθηση",
        image:b1_img,
        new_price: 16.99,
        old_price: 19.99,
    },
    {
        id:2,
        name: "Oracle NoSQL Database",
        image:b2_img,
        new_price: 29.99,
        old_price: 35.99,
    },
];

export default data_product;