import b1_img from "./book_1.jpg";
import b2_img from "./book_2.jpg";
import b3_img from "./book_3.png";

let all_product = [
    {
        id: 1,
        name: "Από την ανασφάλεια στην αυτοπεποίθηση",
        category: "motivational",
        image: b1_img,
        new_price: 16.99,
        old_price: 19.99,
        description: "biblio 1",
        descriptionbox: "biblioooo1",
    },
    {
        id: 2,
        name: "Oracle NoSQL Database",
        category: "ece",
        image: b2_img,
        new_price: 29.99,
        old_price: 35.99,
        description: "biblio 2",
        descriptionbox: "biblioooo2",
    },
    {
        id: 3,
        name: "Τελειώνει με εμάς",
        category: "romantic",
        image: b3_img,
        new_price: 16.99,
        old_price: 19.99,
        description: "biblio 3",
        descriptionbox: "biblioooo3",
    },
];

export default all_product;